<?php 
define('APP_DEBUG', true);
define('APP_NAME', 'ddkf');
define('APP_PATH','./Home/');
require 'ThinkPHP/ThinkPHP.php';

