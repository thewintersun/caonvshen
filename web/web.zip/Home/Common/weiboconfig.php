<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '2979420011' );
define( "WB_SKEY" , '9e14851a6451312ebd5fc626f8950e57' );
define( "WB_CALLBACK_URL" , 'https://api.weibo.com/oauth2/default.html' );
